﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace serialComm
{
    public partial class Form1 : Form
    {
        string dataOUT;
        string Filecontents;
        StringBuilder receivedDataBuffer = new StringBuilder();
        public Form1()
        {
            InitializeComponent();
            txtHexFileContents.ScrollBars = ScrollBars.Vertical;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string [] ports = SerialPort.GetPortNames();
            cBoxCOMPORT.Items.AddRange(ports);
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            try 
            {
                serialPort1.PortName = cBoxCOMPORT.Text;
                serialPort1.BaudRate = Convert.ToInt32(cBoxBaudRate.Text);
                serialPort1.DataBits = Convert.ToInt32(cBoxDataBits.Text);
                serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), cBoxStopBits.Text);
                serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), cBoxParityBits.Text);

                serialPort1.Open();
                progressBar1.Value = 100;

            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
                progressBar1.Value=0;
            }
        }

        private void btnSendData_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen) 
            {
                dataOUT = tBoxDataOut.Text;
                serialPort1.Write(dataOUT);
            }
        }

        private void btnSelectHexFile_Click_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Hex Files (*.hex)|*.hex|All Files (*.*)|*.*";
            openFileDialog.Title = "Select a Hex File";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string selectedFile = openFileDialog.FileName;

                string hexFileContents = File.ReadAllText(selectedFile);

                txtHexFileContents.Text = hexFileContents;
            }
        }

        private void btnSendHexContents_Click(object sender, EventArgs e)
        {
            Filecontents = txtHexFileContents.Text;
            if (serialPort1.IsOpen)
            {
                serialPort1.Write(Filecontents);
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string receivedData = serialPort1.ReadExisting();

            receivedDataBuffer.Append(receivedData);

            UpdateReceivedDataTextBox();
        }

        private void UpdateReceivedDataTextBox()
        {
            if (txtReceivedData.InvokeRequired)
            {
                txtReceivedData.Invoke(new MethodInvoker(UpdateReceivedDataTextBox));
            }
            else
            {
                txtReceivedData.Text = receivedDataBuffer.ToString();
                txtReceivedData.SelectionStart = txtReceivedData.Text.Length;
                txtReceivedData.ScrollToCaret();
            }
        }

        private void btnSaveToFile_Click_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Hex Files (*.hex)|*.hex|All Files (*.*)|*.*";
            saveFileDialog.Title = "Save Received Data";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;

                File.WriteAllText(filePath, receivedDataBuffer.ToString());

                receivedDataBuffer.Clear();

                MessageBox.Show("Data saved to file.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
